package com.peisia.gym.display;

public class Title {
	public static final String VERSION = "v0.1.0";
	public static final String TITLE = "*** 고양이헬스장 관리 프로그램 " + VERSION + " ***";
}
