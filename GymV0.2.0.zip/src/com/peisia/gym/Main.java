package com.peisia.gym;

public class Main {

	public static void main(String[] args) {
		Gym gym = new Gym();
		gym.proc();
	}
}