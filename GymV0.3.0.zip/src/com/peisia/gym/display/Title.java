package com.peisia.gym.display;

import com.peisia.gym.Gym;

public class Title {
	
	public static final String TITLE = 
			"****************************************************************\n" +
			"********         고양이 헬스장 관리 프로그램 " + Gym.VERSION + "  	        ********\n" +
			"****************************************************************";
}
